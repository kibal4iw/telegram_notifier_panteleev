<?php
class Telegram_notifier_panteleevCustomMacros {
    /**
     * @var dummy $module
     */
    public $module;
}