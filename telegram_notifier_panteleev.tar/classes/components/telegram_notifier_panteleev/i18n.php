<?php
$i18n = [
    'module-telegram_notifier_panteleev'            => 'Уведомления в Telegram',
    'header-telegram_notifier_panteleev-config'		=> 'Настроки параметров',
    'option-tg_enable_notification'		            => 'Включить PUSH-уведомления',
    'option-cz_webhook_url'		                    => 'URL corezoid.com',
    'option-tg_bot_api_key'		                    => 'API бота (не используется)',
    'option-tg_chat_id'		                        => 'Код Telegram',
];