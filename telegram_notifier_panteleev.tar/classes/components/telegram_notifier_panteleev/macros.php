<?php
class Telegram_notifier_panteleevMacros {
    /**
     * @var dummy $module
     */
    public $module;

}