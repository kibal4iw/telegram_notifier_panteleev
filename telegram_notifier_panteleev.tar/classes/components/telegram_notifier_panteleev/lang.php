<?php
$C_LANG = [
    'module_name' => 'Уведомения в Telegram '
];