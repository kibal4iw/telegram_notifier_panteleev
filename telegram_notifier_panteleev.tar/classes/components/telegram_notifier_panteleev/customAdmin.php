<?php
class Telegram_notifier_panteleevCustomAdmin {
    /**
     * @var dummy $module
     */
    public $module;

}